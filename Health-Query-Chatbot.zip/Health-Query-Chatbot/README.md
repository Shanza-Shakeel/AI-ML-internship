# 🩺 HealthBot - AI-Powered General Health Assistant

## 📌 Task Objective

This project is built as part of an AI/ML internship to demonstrate the application of large language models (LLMs) in healthcare support systems. The objective is to develop a chatbot application that can assist users by:
- Providing **general health information**
- Performing **symptom analysis** (non-diagnostic)
- Offering **wellness and self-care tips**

The solution is built using `Streamlit` for an interactive frontend and uses the **Zephyr-7B-Beta** LLM from HuggingFace for natural language understanding and response generation.

---

## 🧾 Dataset Used

No traditional tabular dataset is used for this application. Instead, the model leverages pre-trained knowledge from the **Zephyr-7B-Beta** transformer-based LLM, which has been trained on a wide corpus of general knowledge, health-related queries, and dialogue-based data.

Input to the model consists of free-text user queries or symptom descriptions, and responses are generated in real time via HuggingFace API.

---

## 🤖 Model Applied

- **Model Name:** `HuggingFaceH4/zephyr-7b-beta`
- **Model Type:** Instruction-tuned large language model (LLM)
- **API Used:** HuggingFace Inference API
- **Task Type:** Text generation / dialogue

The model processes context-rich prompts dynamically constructed based on user-selected modes:
- **General Health Information**
- **Symptom Analysis**
- **Wellness Tips**

Custom formatting and structured prompts are used in **Symptom Analysis Mode** to guide the model's output into:
1. Possible conditions
2. Recommended self-care
3. When to see a doctor

---

## ✅ Key Results and Findings

- Successfully built a working **Streamlit app** that integrates a HuggingFace-hosted LLM.
- Implemented three user modes:
  - **Symptom Analysis:** Returns likely conditions, self-care tips, and doctor visit suggestions.
  - **General Health Information:** Answers queries like "What is a balanced diet?"
  - **Wellness Tips:** Provides suggestions for daily habits, stress relief, hydration, etc.
- Maintained **conversation history** and **chat export functionality**.
- Included a **.env-secured authentication system** for safe API usage.
- Ensured user safety by displaying a **medical disclaimer** for non-professional guidance.
- User-friendly, WhatsApp-style interface with expandable conversation history.

---

## 🚀 How to Run Locally

1. Clone this repository:
   ```bash
 git clone https://github.com/Shanza-Shakeel/AI-ML-internship/Health-Query-Chatbot.git
   cd Health-Query-Chatbot
