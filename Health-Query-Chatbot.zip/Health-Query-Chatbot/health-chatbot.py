import streamlit as st
import requests
from dotenv import load_dotenv
import os
import json

# Load HF Token
load_dotenv()
HF_TOKEN = os.getenv("HF_TOKEN")
if not HF_TOKEN:
    st.error("❌ Add your HF token to `.env` file!")
    st.stop()

# Model & API Setup
MODEL_NAME = "HuggingFaceH4/zephyr-7b-beta"
API_URL = f"https://api-inference.huggingface.co/models/{MODEL_NAME}" 
headers = {"Authorization": f"Bearer {HF_TOKEN}"}

# Sidebar for App Info
with st.sidebar:
    st.title("🤖 HealthBot Info")
    st.markdown("""
    This chatbot uses the **Zephyr-7B-Beta** model to provide:
    - General health information
    - Symptom analysis
    - Wellness tips
    """)

    st.markdown("### 🧭 Choose Mode:")
    query_type = st.radio(
        "Select query type:",
        ["General Health Information", "Symptom Analysis", "Wellness Tips"],
        label_visibility="collapsed"
    )

    symptom_mode = query_type == "Symptom Analysis"

    # Toggle history visibility
    show_history = st.checkbox("📜 Show Conversation History", value=False)
    st.markdown("---")

# Initialize session states
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Main Title
st.markdown("<h1 style='text-align: center; color: #1E90FF;'>🩺 General Health Assistant</h1>", unsafe_allow_html=True)

# Chat display area
chat_container = st.container()

# User Input Section
with st.form("chat_form", clear_on_submit=True):
    user_input = st.text_area("💬 Describe your health query or symptoms:", 
                              placeholder="e.g. 'headache and fever for 2 days'",
                              height=100)
    
    submit_button = st.form_submit_button("💬 Send")  # WhatsApp-style send icon

# Process Query
if submit_button and user_input.strip():
    try:
        # Append user message to chat history
        st.session_state.chat_history.append({
            "query": user_input,
            "mode": query_type
        })

        # Prepare enhanced prompt based on mode
        if symptom_mode:
            prompt = f"""<|user|>
            Analyze these symptoms: {user_input}
            Provide:
            1. Possible conditions (list 2-3 common ones)
            2. Recommended self-care
            3. When to see a doctor
            </s><|assistant|>"""
        else:
            prompt = f"<|user|>{user_input}</s><|assistant|>"
        
        # Call API with loading indicator
        with st.spinner("🔍 Analyzing your query..."):
            response = requests.post(
                API_URL,
                headers=headers,
                json={
                    "inputs": prompt,
                    "parameters": {"max_new_tokens": 300}
                },
                timeout=45
            )
        
        if response.status_code == 200:
            answer = response.json()[0]["generated_text"].split("<|assistant|>")[-1]

            # Format symptom analysis
            if symptom_mode:
                answer = answer.replace("1.", "🔍 **Possible Conditions:**") \
                              .replace("2.", "\n\n💡 **Self-Care Tips:**") \
                              .replace("3.", "\n\n⚠️ **When to See a Doctor:**")
            
            # Update last chat entry with response
            st.session_state.chat_history[-1]["response"] = answer
            
            # Display response
            with chat_container:
                with st.chat_message("user"):
                    st.markdown(f"**You:** {user_input}")
                
                with st.chat_message("assistant"):
                    st.markdown(f"**HealthBot:** {answer}")
                    
                    if symptom_mode:
                        st.warning("""
                        ℹ️ This is not a diagnosis. Consult a healthcare professional 
                        for medical advice.
                        """)
        
        else:
            st.error(f"API Error {response.status_code}: {response.text}")
    
    except Exception as e:
        st.error(f"🚨 Error: {str(e)}")

# Enhanced History Section (in sidebar)
if show_history and st.session_state.chat_history:
    with st.sidebar:
        st.subheader("📜 Conversation History")
        if st.button("🧹 Clear History"):
            st.session_state.chat_history = []
            st.rerun()
        
        for i, chat in enumerate(st.session_state.chat_history):
            with st.expander(f"Chat {i+1} - {chat['mode']}", expanded=False):
                st.markdown(f"**You:** {chat['query']}")
                st.markdown(f"**Bot:** {chat.get('response', 'No response generated')}")
                
                if st.button(f"💾 Export #{i+1}", key=f"export_{i}"):
                    st.download_button(
                        label="Download as JSON",
                        data=json.dumps(chat, indent=2),
                        file_name=f"healthbot_convo_{i+1}.json",
                        mime="application/json"
                    )

# Footer
st.markdown("""
<style>
.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    text-align: center;
    padding: 10px;
    font-size: 0.8em;
    color: gray;
}
</style>
<div class="footer">
© 2025 HealthBot | Not a substitute for professional medical advice
</div>
""", unsafe_allow_html=True)
